  <!-- Footer -->
  <footer>
    <div class="footer-inner">
      <div>
        <div class="footer-logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.png" alt="結建築工房"></div>
        <p>〒000-0000 〇〇県〇〇市〇〇町1-2-3<br>TEL: 000-000-0000</p>
      </div>
      <div class="footer-links">
        <ul>
          <li><a href="#concept">私たちの想い</a></li>
          <li><a href="#works">施工事例</a></li>
        </ul>
        <ul>
          <li><a href="#strengths">選ばれる理由</a></li>
          <li><a href="#company">会社案内</a></li>
          <li><a href="#">プライバシーポリシー</a></li>
        </ul>
      </div>
    </div>
    <div class="copyright">
      &copy; <?php echo date('Y'); ?> Musubi Kenchiku Koubou. All Rights Reserved.
    </div>
  </footer>

  <!-- Scripts -->
  <script>
    // Hamburger menu toggle
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    
    if (hamburger) {
      hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navLinks.classList.toggle('active');
      });
      
      // Close menu when a link is clicked
      document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', () => {
          hamburger.classList.remove('active');
          navLinks.classList.remove('active');
        });
      });
    }

    // Header scroll effect
    window.addEventListener('scroll', () => {
      const header = document.getElementById('header');
      if (window.scrollY > 50) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    });

    // Smooth scroll
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
          window.scrollTo({
            top: target.offsetTop,
            behavior: 'smooth'
          });
        }
      });
    });
  </script>
  <?php wp_footer(); ?>
</body>
</html>

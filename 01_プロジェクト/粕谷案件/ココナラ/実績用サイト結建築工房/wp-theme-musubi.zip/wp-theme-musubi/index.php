<?php get_header(); ?>

  <!-- Hero Section -->
  <section class="hero">
    <div class="hero-bg" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/fv_hero.png');"></div>
    <div class="hero-overlay"></div>
    <div class="hero-content">
      <h1 class="hero-title">
        <?php
          $hero_title = get_field('hero_title');
          echo $hero_title ? nl2br(esc_html($hero_title)) : '人生を紡ぐ、美しい住まい。';
        ?>
      </h1>
      <p class="hero-subtitle">
        <?php
          $hero_subtitle = get_field('hero_subtitle');
          echo $hero_subtitle ? nl2br(esc_html($hero_subtitle)) : '洗練された意匠と、確かな性能が交差する。<br>結建築工房が提案する、新しい暮らしのカタチ。';
        ?>
      </p>
    </div>
    <div class="scroll-down">
      SCROLL
      <div class="scroll-line"></div>
    </div>
  </section>

  <!-- Concept Section -->
  <section id="concept" class="section-padding">
    <div class="container">
      <div class="concept-wrapper">
        <div class="concept-text">
          <h2 class="section-title" style="align-items: flex-start;">
            <span class="en">CONCEPT</span>
            家族の絆を結び、<br>美しく永く住まえる家。
          </h2>
          <p>
            家づくりは、単なる箱をつくることではありません。<br>
            それはご家族のこれからの人生の舞台を創り上げる、尊いプロジェクトです。
          </p>
          <p>
            私たち結建築工房は、流行に左右されない普遍的な美しさを持った「意匠設計」と、何十年先も安心して暮らせる「住宅性能」を高い次元で融合させています。
          </p>
          <p>
            光の入り方、風の通り道、木の手触り。<br>
            そのすべてが調和した空間は、住まう人の心を穏やかにし、日々の生活に豊かな余白をもたらします。
          </p>
        </div>
        <div class="concept-image">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/concept_interior.png" alt="美しい木の温もりを感じるリビング空間">
        </div>
      </div>
    </div>
  </section>

  <!-- Works Section -->
  <section id="works" class="section-padding bg-gray">
    <div class="container">
      <h2 class="section-title">
        <span class="en">OUR WORKS</span>
        施工事例
      </h2>
      <p class="section-desc">光と風をデザインした、多様なライフスタイルに応える住まい。</p>
      
      <div class="works-grid">
        <!-- Work 1 -->
        <article class="work-card">
          <div class="work-img">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/work_1.png" alt="陽光溢れるモダンキュービックの家">
          </div>
          <div class="work-info">
            <span class="work-tag">デザイン住宅</span>
            <h3 class="work-title">陽光溢れるモダンキュービックの家</h3>
          </div>
        </article>
        
        <!-- Work 2 -->
        <article class="work-card">
          <div class="work-img">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/work_2.png" alt="深い軒とテラスが繋がる木の家">
          </div>
          <div class="work-info">
            <span class="work-tag">平屋ベース</span>
            <h3 class="work-title">深い軒とテラスが自然と繋がる、木の温もり</h3>
          </div>
        </article>
        
        <!-- Work 3 -->
        <article class="work-card">
          <div class="work-img">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/work_3.png" alt="美しい陰影を描く和モダンの平屋">
          </div>
          <div class="work-info">
            <span class="work-tag">和モダン</span>
            <h3 class="work-title">美しい陰影を描く、洗練された和の装い</h3>
          </div>
        </article>
      </div>
    </div>
  </section>

  <!-- Strengths Section -->
  <section id="strengths" class="section-padding">
    <div class="container">
      <h2 class="section-title">
        <span class="en">STRENGTHS</span>
        結建築工房が選ばれる理由
      </h2>
      <p class="section-desc">目に見える美しさと、目に見えない安心を。</p>
      
      <div class="strengths-grid">
        <div class="strength-item">
          <div class="strength-num">01</div>
          <div class="strength-content">
            <h3>時を経ても色褪せない「洗練された意匠設計」</h3>
            <p>経験豊富な専属の建築家が、敷地のポテンシャルを最大限に引き出すプランをご提案します。外観のプロポーションから、ミリ単位でこだわるインテリアの納まりまで、圧倒的な美しさを追求します。</p>
          </div>
        </div>
        
        <div class="strength-item">
          <div class="strength-num">02</div>
          <div class="strength-content">
            <h3>家族を守り抜く「妥協なき住宅性能」</h3>
            <p>日本最高等級の耐震性能と、高気密・高断熱仕様を標準採用。1年中快適な室温を保ちながら、ランニングコストを抑えるエコな設計。見えない部分の構造材にも最高品質の木材を使用しています。</p>
          </div>
        </div>
        
        <div class="strength-item">
          <div class="strength-num">03</div>
          <div class="strength-content">
            <h3>地域密着だからこその「生涯サポート」</h3>
            <p>建てて終わりではなく、お引き渡しからが本当のお付き合いの始まりです。定期点検はもちろん、日々の些細なお困りごとにもすぐに駆けつける、頼れる地元のパートナーであり続けます。</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Company Section -->
  <section id="company" class="section-padding bg-gray">
    <div class="container">
      <h2 class="section-title">
        <span class="en">COMPANY</span>
        会社案内
      </h2>
      
      <div class="company-wrapper">
        <div class="company-president">
          <?php $president_image = get_field('president_image'); ?>
          <?php if($president_image): ?>
            <img src="<?php echo esc_url($president_image); ?>" alt="代表取締役" style="width: 100%; height: auto; border-radius: 4px;">
          <?php else: ?>
            <div style="background-color: #e0e0e0; width: 100%; aspect-ratio: 3/4; display: flex; align-items: center; justify-content: center; border-radius: 4px; color: #888; text-align: center; padding: 20px; font-weight: 500;">
              ここに代表の写真が入ります
            </div>
          <?php endif; ?>
        </div>
        <div class="company-info">
          <h3>「家をつくることは、幸せをつくること」</h3>
          <p>
            私たち結建築工房は、創業以来「お客様の期待を超える感動を提供する」という信念のもと、一棟一棟真心を込めて家づくりに向き合ってまいりました。<br><br>
            大切なご家族が、毎日笑顔で安全に暮らせる場所。そんなかけがえのない空間を創り上げる責任と誇りを胸に、これからも地域に根ざした誠実な工務店として歩んでまいります。
          </p>
          <table class="company-table">
            <tr>
              <th>会社名</th>
              <td>株式会社 結建築工房（Musubi Kenchiku Koubou）</td>
            </tr>
            <tr>
              <th>所在地</th>
              <td>〒000-0000 〇〇県〇〇市〇〇町1-2-3</td>
            </tr>
            <tr>
              <th>事業内容</th>
              <td>注文住宅の設計・施工、リノベーション、店舗設計</td>
            </tr>
            <tr>
              <th>許可番号</th>
              <td>〇〇県知事登録 第〇〇〇〇号</td>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </section>

  <!-- CTA Section -->
  <section id="contact" class="cta-section">
    <div class="container">
      <h2>理想の住まいづくりを、ここから始めませんか。</h2>
      <p>モデルハウスのご見学、家づくりに関するご相談は無料です。<br>どうぞお気軽にお問い合わせください。</p>
      
      <div class="cta-buttons">
        <a href="#" class="btn-large btn-outline">まずは資料請求する</a>
        <a href="#" class="btn-large btn-primary">モデルハウス来場予約</a>
      </div>
    </div>
  </section>

<?php get_footer(); ?>

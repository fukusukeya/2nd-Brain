<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="結建築工房は、洗練されたデザインと確かな性能が交差する、新しい暮らしのカタチをご提案する工務店です。">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

  <!-- Header -->
  <header id="header">
    <div class="logo">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.png" alt="結建築工房" class="logo-default">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-black.png" alt="結建築工房" class="logo-scrolled">
      </a>
    </div>
    <div class="hamburger">
      <span></span><span></span><span></span>
    </div>
    <ul class="nav-links">
      <li><a href="#concept">私たちの想い</a></li>
      <li><a href="#works">施工事例</a></li>
      <li><a href="#strengths">選ばれる理由</a></li>
      <li><a href="#company">会社案内</a></li>
      <li><a href="#contact" class="btn-contact">資料請求・来場予約</a></li>
    </ul>
  </header>

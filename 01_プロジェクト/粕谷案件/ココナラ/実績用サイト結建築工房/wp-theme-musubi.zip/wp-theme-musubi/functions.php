<?php
/**
 * Theme Functions
 */

if ( ! function_exists( 'musubi_theme_setup' ) ) :
	function musubi_theme_setup() {
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
	}
endif;
add_action( 'after_setup_theme', 'musubi_theme_setup' );

function musubi_scripts() {
	// Google Fonts
	wp_enqueue_style( 'musubi-google-fonts', 'https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500&family=Noto+Sans+JP:wght@300;400;500;700&family=Noto+Serif+JP:wght@400;500;600&display=swap', array(), null );
	
	// Main Stylesheet
	wp_enqueue_style( 'musubi-main-style', get_template_directory_uri() . '/assets/css/main.css', array(), '1.0.0' );
}
add_action( 'wp_enqueue_scripts', 'musubi_scripts' );
